# Dev Guide

# breadcrumb

Breadcrumb can applied generally and specifically from controller.  example included in dashboard controller for specific breadcrumb while generically is applied through `GlobalTemplateServiceProvider` provider. 
