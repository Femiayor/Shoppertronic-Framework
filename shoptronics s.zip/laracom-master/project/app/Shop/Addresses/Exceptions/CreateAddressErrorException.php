<?php

namespace App\Shop\Addresses\Exceptions;

class CreateAddressErrorException extends \Exception
{
}
