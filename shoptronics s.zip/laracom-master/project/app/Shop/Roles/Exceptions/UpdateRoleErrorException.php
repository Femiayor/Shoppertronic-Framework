<?php

namespace App\Shop\Roles\Exceptions;

class UpdateRoleErrorException extends \Exception
{
}
