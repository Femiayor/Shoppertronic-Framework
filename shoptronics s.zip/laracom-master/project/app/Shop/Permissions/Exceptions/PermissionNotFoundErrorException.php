<?php

namespace App\Shop\Permissions\Exceptions;

class PermissionNotFoundErrorException extends \Exception
{
}
