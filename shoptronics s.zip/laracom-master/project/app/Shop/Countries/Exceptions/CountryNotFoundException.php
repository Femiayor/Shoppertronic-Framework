<?php

namespace App\Shop\Countries\Exceptions;

class CountryNotFoundException extends \Exception
{
}
