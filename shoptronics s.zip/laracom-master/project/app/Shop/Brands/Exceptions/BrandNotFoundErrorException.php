<?php

namespace App\Shop\Brands\Exceptions;

class BrandNotFoundErrorException extends \Exception
{
}
