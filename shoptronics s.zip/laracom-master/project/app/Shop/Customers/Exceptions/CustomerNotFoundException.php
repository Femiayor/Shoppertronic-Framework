<?php

namespace App\Shop\Customers\Exceptions;

class CustomerNotFoundException extends \Exception
{
}
