<?php

namespace App\Shop\Carts\Requests;

interface CheckoutInterface
{
    public function rules();
}
