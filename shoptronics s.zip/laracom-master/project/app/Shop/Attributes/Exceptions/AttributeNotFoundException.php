<?php

namespace App\Shop\Attributes\Exceptions;

class AttributeNotFoundException extends \Exception
{
}
