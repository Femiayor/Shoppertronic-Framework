<?php

namespace App\Shop\Couriers\Exceptions;

use Doctrine\Instantiator\Exception\InvalidArgumentException;

class CourierInvalidArgumentException extends InvalidArgumentException
{
}
