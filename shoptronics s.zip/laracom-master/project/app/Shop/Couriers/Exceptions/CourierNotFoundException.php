<?php

namespace App\Shop\Couriers\Exceptions;

class CourierNotFoundException extends \Exception
{
}
