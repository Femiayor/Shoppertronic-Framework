<?php

namespace App\Shop\Orders\Exceptions;

use Doctrine\Instantiator\Exception\InvalidArgumentException;

class OrderInvalidArgumentException extends InvalidArgumentException
{
}
