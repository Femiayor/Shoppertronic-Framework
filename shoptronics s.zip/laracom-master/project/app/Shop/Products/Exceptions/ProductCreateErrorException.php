<?php

namespace App\Shop\Products\Exceptions;

class ProductCreateErrorException extends \Exception
{
}
